# GITAM SGPA Calculator v2

## Setup (one-time)

```bash
python -m venv venv

# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

## Run

```bash
python app.py
```

Open http://localhost:5000

## Project structure

```
sgpa-v2/
├── .env                 ← API key (already filled)
├── app.py               ← Flask backend + OpenAI vision
├── requirements.txt
└── templates/
    └── index.html       ← All frontend (HTML + CSS + JS in one file)
```

## How to use

1. Go to GITAM portal → Results → Semester X
2. Scroll so BOTH the Sessional Grades table AND Internal Marks table are visible
3. Take a screenshot (Win+Shift+S or Cmd+Shift+4)
4. Upload on the app → click "Analyse with AI"
5. Review extracted subjects — check credits, toggle absolute grading if needed
6. Enter current CGPA + credits (optional) for updated CGPA
7. Click Calculate SGPA
